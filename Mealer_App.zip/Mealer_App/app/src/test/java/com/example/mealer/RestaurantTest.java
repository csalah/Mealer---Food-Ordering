package com.example.mealer;

import junit.framework.TestCase;

public class RestaurantTest extends TestCase {

    public void testGetUID() {
        float input = Float.parseFloat("testResto");
        float output = Float.parseFloat("test uid");
        float expected = Float.parseFloat("test uid");

        Restaurant resto = new Restaurant();
        resto.UID = String.valueOf(input);

        output = Float.parseFloat(resto.getUID());
        assertEquals(expected, output);





    }
}