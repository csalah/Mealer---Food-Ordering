package com.example.mealer;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

public class RestaurantMenuTest extends TestCase {

    public void testGetItemListSize() {
        Item item = new Item();
        Item item2 = new Item();
        Item item3 = new Item();
        List<Item>  list = new ArrayList<>();
        list.add(item);
        list.add(item2);
        list.add(item3);
        RestaurantMenu resto = new RestaurantMenu();
        resto.listItems = (ArrayList<Item>) list;
        int input = list.size();
        int output;
        int expected = 3;
        output = resto.getItemListSize(list);

        assertEquals(expected,output);




    }
}