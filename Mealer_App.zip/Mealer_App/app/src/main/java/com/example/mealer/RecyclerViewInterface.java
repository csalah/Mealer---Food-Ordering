package com.example.mealer;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
