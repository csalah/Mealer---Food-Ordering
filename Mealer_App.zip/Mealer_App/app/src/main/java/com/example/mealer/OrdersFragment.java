package com.example.mealer;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link OrdersFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OrdersFragment extends Fragment implements RecyclerViewInterface{
    DatabaseReference databaseReferenceAllOrders;
    private ArrayList<Order> listAllOrders;
    private String clientEmail, uid;
    FirebaseUser user;
    RecyclerView recyclerView;
    OrdersAdapter adapter;
    Dialog reviewDialog;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public OrdersFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment OrdersFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OrdersFragment newInstance(String param1, String param2) {
        OrdersFragment fragment = new OrdersFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_orders, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        user = FirebaseAuth.getInstance().getCurrentUser();
        uid = user.getUid();

        reviewDialog = new Dialog(getContext());

        listAllOrders = new ArrayList<>();
        recyclerView = view.findViewById(R.id.RecyclerViewOrders);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new OrdersAdapter(getContext(),listAllOrders,this);
        recyclerView.setAdapter(adapter);

        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Users");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String email = snapshot.child(uid).child("email").getValue(String.class);
                clientEmail = email.trim();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        databaseReferenceAllOrders = FirebaseDatabase.getInstance().getReference("Orders");
        databaseReferenceAllOrders.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listAllOrders.clear();
                for(DataSnapshot dataSnapshot: snapshot.getChildren()) {
                    if(dataSnapshot.child("customerEmail").getValue().toString().equals(clientEmail)){
                        Order order = new Order();
                        List<CartedItem> listItems;
                        listItems = (List<CartedItem>) dataSnapshot.child("listItems").getValue();
                        String total = dataSnapshot.child("total").getValue().toString();
                        String restoNameOrder = dataSnapshot.child("restaurantNameOrder").getValue().toString();
                        String status = dataSnapshot.child("status").getValue().toString();
                        String email = dataSnapshot.child("customerEmail").getValue().toString();
                        order.setListItems(listItems);
                        order.setTotal(total);
                        order.setRestaurantName(restoNameOrder);
                        order.setStatus(status);
                        order.setCustomerEmail(email);

                        listAllOrders.add(order);


                    }




                }adapter.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    @Override
    public void onItemClick(int position) {
        String tempResto = listAllOrders.get(position).getRestaurantNameOrder();
        String status = listAllOrders.get(position).getStatus();
        String resto = listAllOrders.get(position).getRestaurantNameOrder().toUpperCase(Locale.ROOT);
        openReviewDialog(tempResto,status,resto);
    }

    private void openReviewDialog(String tempResto, String status, String resto) {
        reviewDialog.setContentView(R.layout.review_complaint_dialog);
        reviewDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        Button submitComplaint = (Button) reviewDialog.findViewById(R.id.btnSubmitComplaint) ;
        submitComplaint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!status.equals("Accepted")){
                    Toast.makeText(getContext(),"Please wait until order has been accepted prior to submiting complaint",Toast.LENGTH_LONG).show();
                } else {
                Intent intent = new Intent(getContext(),CreateComplaint.class);
                intent.putExtra("restoName", tempResto);
                startActivity(intent);}
            }
        });


        ImageView close = (ImageView) reviewDialog.findViewById(R.id.imageViewClose);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reviewDialog.dismiss();
            }
        }); reviewDialog.show();

    }
}