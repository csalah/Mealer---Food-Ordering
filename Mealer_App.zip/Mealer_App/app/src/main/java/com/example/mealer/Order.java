package com.example.mealer;

import java.util.List;

public class Order {
    private String restaurantNameOrder, customerEmail, status,total;
    private List<CartedItem> listItems;

    public Order(){

    }

    public Order( String restaurantNameOrder , String customerEmail, List<CartedItem> n, String status, String total){
        this.restaurantNameOrder = restaurantNameOrder;
        this.customerEmail = customerEmail;
        this.listItems = n;
        this.status = status;
        this.total= total;

    }






    public String getRestaurantNameOrder() {
        return restaurantNameOrder;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantNameOrder = restaurantName;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public List<CartedItem> getListItems() {
        return listItems;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setListItems(List<CartedItem> listItems) {
        this.listItems = listItems;
    }
}
