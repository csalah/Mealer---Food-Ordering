package com.example.mealer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RestaurantOrderList extends AppCompatActivity implements RecyclerViewInterface{
    private String nameRestaurant;
    DatabaseReference databaseReferenceAllOrders;
    private ArrayList<Order> listAllOrders;
    FirebaseUser user;
    RecyclerView recyclerView;
    RestaurantOrderListAdapter adapter;
    String nameRestoNoCap;
    Dialog ordersDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_order_list);
        ordersDialog = new Dialog(this);

        Intent intent = getIntent();
        nameRestaurant = intent.getStringExtra("RestaurantName");
        nameRestaurant = nameRestaurant.toLowerCase(Locale.ROOT);
        nameRestoNoCap = nameRestaurant.substring(0,1).toUpperCase(Locale.ROOT)+nameRestaurant.substring(1);

        listAllOrders = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerViewOrdersResto);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RestaurantOrderListAdapter(this,listAllOrders,this);
        recyclerView.setAdapter(adapter);

        ImageView returnToDash = (ImageView) findViewById(R.id.imageViewReturnOrdersResto);
        returnToDash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        databaseReferenceAllOrders = FirebaseDatabase.getInstance().getReference("Orders");
        databaseReferenceAllOrders.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listAllOrders.clear();
                for(DataSnapshot dataSnapshot: snapshot.getChildren()) {
                    if(dataSnapshot.child("restaurantNameOrder").getValue().toString().equals(nameRestoNoCap)){
                        Order order = new Order();
                        List<CartedItem> listItems;
                        listItems = (List<CartedItem>) dataSnapshot.child("listItems").getValue();
                        String total = dataSnapshot.child("total").getValue().toString();
                        String restoNameOrder = dataSnapshot.child("restaurantNameOrder").getValue().toString();
                        String status = dataSnapshot.child("status").getValue().toString();
                        String email = dataSnapshot.child("customerEmail").getValue().toString();
                        order.setListItems(listItems);
                        order.setTotal(total);
                        order.setRestaurantName(restoNameOrder);
                        order.setStatus(status);
                        order.setCustomerEmail(email);

                        listAllOrders.add(order);


                    }




                }adapter.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }// end of onCreate

    @Override
    public void onItemClick(int position) {
        openOrdersDialog(listAllOrders.get(position));

    }

    private void openOrdersDialog(Order order) {
        ordersDialog.setContentView(R.layout.restaurant_orders_action_dialog);
        ordersDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        Button btnDecline = ordersDialog.findViewById(R.id.btnDecline);
        btnDecline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!order.getStatus().equals("Pending")){
                    Toast.makeText(getApplicationContext(),"This order was either already completed or declined previously", Toast.LENGTH_LONG).show();
                } else{   declineOrder(order);   }
            }
        });

        Button btnAccept = ordersDialog.findViewById(R.id.btnAccept);
        btnAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!order.getStatus().equals("Pending")){
                    Toast.makeText(getApplicationContext(),"This order was either already completed or declined previously", Toast.LENGTH_LONG).show();
                } else{   acceptOrder(order);   }
            }
        });

        ImageView close = (ImageView) ordersDialog.findViewById(R.id.imageViewClose);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ordersDialog.dismiss();
            }
        }); ordersDialog.show();
    }

    private void declineOrder(Order order) {
        databaseReferenceAllOrders = FirebaseDatabase.getInstance().getReference("Orders");
        databaseReferenceAllOrders.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot: snapshot.getChildren()) {
                    if(dataSnapshot.child("restaurantNameOrder").getValue().toString().equals(nameRestoNoCap) && dataSnapshot.child("customerEmail").getValue().toString().equals(order.getCustomerEmail())){
                        int index = order.getCustomerEmail().indexOf("@");
                        String emailNoDomain = order.getCustomerEmail().substring(0,index);
                        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Orders").child(emailNoDomain + ": " + nameRestoNoCap).child("status");
                        db.setValue("Declined");
                        Toast.makeText(getApplicationContext(), "Order declined", Toast.LENGTH_SHORT).show();
                        ordersDialog.dismiss();

                    }




                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }


    private void acceptOrder(Order order) {

        databaseReferenceAllOrders = FirebaseDatabase.getInstance().getReference("Orders");
        databaseReferenceAllOrders.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot: snapshot.getChildren()) {
                    if(dataSnapshot.child("restaurantNameOrder").getValue().toString().equals(nameRestoNoCap) && dataSnapshot.child("customerEmail").getValue().toString().equals(order.getCustomerEmail())){
                        int index = order.getCustomerEmail().indexOf("@");
                        String emailNoDomain = order.getCustomerEmail().substring(0,index);
                        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Orders").child(emailNoDomain + ": " + nameRestoNoCap).child("status");
                        db.setValue("Accepted");
                        Toast.makeText(getApplicationContext(), "Order accepted", Toast.LENGTH_SHORT).show();
                        ordersDialog.dismiss();

                    }




                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}