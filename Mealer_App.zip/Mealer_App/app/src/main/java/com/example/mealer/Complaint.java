package com.example.mealer;

public class Complaint {

    private String restaurantName, complaintDetails;

    public Complaint() {

    }
    public Complaint(String restaurantName, String complaintDetails){
        this.restaurantName = restaurantName;
        this.complaintDetails = complaintDetails;
    }// end of constructor

    public String getRestaurantName() {
        return restaurantName;
    }

    public String getComplaintDetails() {
        return complaintDetails;
    }

    public void setComplaintDetails(String complaintDetails) {
        this.complaintDetails = complaintDetails;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }
}// end of Complaint class
