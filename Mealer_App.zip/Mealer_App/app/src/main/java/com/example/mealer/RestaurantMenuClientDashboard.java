package com.example.mealer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RestaurantMenuClientDashboard extends AppCompatActivity implements RecyclerViewInterface{

    TextView restaurantName, recommended;
    ImageView returnMenu;
    RecyclerView recyclerView;
    ArrayList<Item> list;
    DatabaseReference databaseReference;
    OurItemsClientDashAdapter adapter;
    Dialog dialogOnItemClick;
    FirebaseUser user;
    String uid, clientEmail;
    FirebaseDatabase rootNode;
    DatabaseReference reference;
    List<CartedItem> cartItems;
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_menu_client_dashboard);

        searchView = (SearchView) findViewById(R.id.search_bar_items);
        searchView.clearFocus();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                filterList(s);
                return true;
            }
        });


        cartItems = new ArrayList<>();

        user = FirebaseAuth.getInstance().getCurrentUser();
        uid = user.getUid();

        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Users");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String email = snapshot.child(uid).child("email").getValue().toString();
                clientEmail = email;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        dialogOnItemClick = new Dialog(this);

        restaurantName = findViewById(R.id.textViewNameRestaurant);
        Intent intent = getIntent();
        String nameRestaurant = intent.getStringExtra("RestaurantName");
        restaurantName.setText(nameRestaurant);

        recyclerView = findViewById(R.id.recyclerView);
        databaseReference = FirebaseDatabase.getInstance().getReference("Items");
        list = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new OurItemsClientDashAdapter(this, list,this);
        recyclerView.setAdapter(adapter);

        String nameRestoCap = nameRestaurant.toUpperCase(Locale.ROOT).trim();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot: snapshot.getChildren()) {
                    if(dataSnapshot.child("restaurantName").getValue().toString().equals(nameRestoCap)){
                        Item item = dataSnapshot.getValue(Item.class);
                        list.add(item);
                    } adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        returnMenu = findViewById(R.id.imageViewReturn);
        returnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private void filterList(String s) {
        ArrayList<Item> filteredList = new ArrayList<>();
        for(Item item : list){
            if(item.getItem().toLowerCase(Locale.ROOT).contains(s.toLowerCase(Locale.ROOT))||
                    item.getDescription().toLowerCase(Locale.ROOT).contains(s.toLowerCase(Locale.ROOT))||
                    item.getCategory().toLowerCase(Locale.ROOT).contains(s.toLowerCase(Locale.ROOT))||
                    item.getPrice().toString().toLowerCase(Locale.ROOT).contains(s.toLowerCase(Locale.ROOT))||
                    item.getRestaurantName().toLowerCase(Locale.ROOT).contains(s.toLowerCase(Locale.ROOT))){
                filteredList.add(item);
            }
        }  if(filteredList.isEmpty()){
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        } else {
            adapter.setFilteredList(filteredList);
        }

    }

    @Override
    public void onItemClick(int position) {
        Item item = list.get(position);
        openDialog(position, item, clientEmail);

    }

    private void openDialog(int position, Item item, String clientEmail) {
        dialogOnItemClick.setContentView(R.layout.client_dash_add_item_dialog);
        dialogOnItemClick.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        EditText editTextQuantity = dialogOnItemClick.findViewById(R.id.editTextQuantity);
        editTextQuantity.setText("1");
        Button addToCart = dialogOnItemClick.findViewById(R.id.btnAddToCart);
        addToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String quantityInput = editTextQuantity.getText().toString().trim();
                if(quantityInput.equals("0")){
                    editTextQuantity.setError("Invalid input");
                    editTextQuantity.requestFocus();
                    return;
                }

                String price = Double.toString(item.getPrice());



                CartedItem cartedItem = new CartedItem(item.getRestaurantName(),item.getItem(),item.getDescription(),price,quantityInput,clientEmail);

                rootNode = FirebaseDatabase.getInstance();
                reference  = rootNode.getReference("CartedItems");
                String emailNoDomain;
                int index = clientEmail.indexOf("@");
                emailNoDomain = clientEmail.substring(0,index);

                for(CartedItem item : cartItems){
                    if(item.getItem().equals(cartedItem.getItem())){
                        if(item.getEmail().equals(cartedItem.getEmail())){
                            if(item.getRestaurantName().equals(cartedItem.getRestaurantName())){
                                Toast.makeText(RestaurantMenuClientDashboard.this, "Item is already in your cart. Please remove it from your cart first or complete order", Toast.LENGTH_LONG).show();
                                return;
                            }
                        }
                    }
                }
                FirebaseDatabase.getInstance().getReference("CartedItems").child(emailNoDomain+": "+ item.getRestaurantName()+ ": "+ item.getItem()).setValue(cartedItem).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            cartItems.add(cartedItem);
                            Toast.makeText(RestaurantMenuClientDashboard.this, "Delicious dish has been added to your cart", Toast.LENGTH_LONG).show();
                            dialogOnItemClick.dismiss();
                        }//taskSuccessfully
                        else {Toast.makeText(RestaurantMenuClientDashboard.this, "Unable to add item to your cart", Toast.LENGTH_LONG).show();}
                    }
                });
            }
        });
        ImageView close = dialogOnItemClick.findViewById(R.id.imageViewClose);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogOnItemClick.dismiss();
            }
        });  dialogOnItemClick.show();


    }
}