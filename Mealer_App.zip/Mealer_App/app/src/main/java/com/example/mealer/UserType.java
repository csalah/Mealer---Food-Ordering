package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class UserType extends AppCompatActivity implements View.OnClickListener {
    String userType;
    Button client;
    Button restaurant;
    ImageView mealerApp;
    ImageView mealerBackground;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_type);
        client = (Button) findViewById(R.id.btnClient);
        restaurant = (Button) findViewById(R.id.btnRestaurant);
        mealerApp = (ImageView) findViewById(R.id.imageView);
        mealerBackground = (ImageView) findViewById(R.id.mealerBackground);
        client.setOnClickListener(this);
        restaurant.setOnClickListener(this);
        mealerApp.setOnClickListener(this);
        mealerBackground.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnClient:
                userType = "0";
                    startActivity(new Intent(this,RegisterClient.class));
                break;
            case R.id.btnRestaurant:
                userType = "1";
                startActivity(new Intent(this, RegisterRestaurant.class));
                break;

            case R.id.imageView :
                case R.id.mealerBackground:
                    startActivity(new Intent(this, UserLoginRegister.class));
                    break;


        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(),UserLoginRegister.class));
    }

    public String getUserType(){
        return userType;
    }

}