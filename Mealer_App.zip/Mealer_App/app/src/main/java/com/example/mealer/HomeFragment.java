package com.example.mealer;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment implements RecyclerViewInterface{
    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    OurAdapterAvailableRestaurant adapter;
    ArrayList<RestaurantAvailable> listAvailableRestaurants;
    SearchView searchView;


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);

        }

    }// end of onCreate

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        searchView = getView().findViewById(R.id.search_bar);
        searchView.clearFocus();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                filterList(s);
                return true;
            }
        });
        super.onViewCreated(view, savedInstanceState);
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        recyclerView = view.findViewById(R.id.restoRecyclerView);
        listAvailableRestaurants = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new OurAdapterAvailableRestaurant(getContext(),listAvailableRestaurants,this);
        recyclerView.setAdapter(adapter);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listAvailableRestaurants.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    if (dataSnapshot.child("UID").exists() && dataSnapshot.child("status").getValue().toString().equals("Active")) {
                        Restaurant restaurant = dataSnapshot.getValue(Restaurant.class);
                        RestaurantAvailable restaurantAvailable = new RestaurantAvailable();
                        String name = restaurant.getRestaurantName();
                        name = name.toLowerCase(Locale.ROOT);
                        String nameCap = name.substring(0,1).toUpperCase(Locale.ROOT) + name.substring(1);
                        String description = restaurant.getDescription();
                        String apt = restaurant.getAptNumber();
                        String street = restaurant.getStreetAddress();
                        String postalCode = restaurant.getPostalCode();
                        String city = restaurant.getCity();
                        String fullAddress = null;
                        String rating = restaurant.getRating();
                        String totalRating = restaurant.getRating();
                        String totalReview = restaurant.getTotalReviews();
                        if(apt.equals("")){fullAddress = street + ", " + city + ", " + "Ontario " + postalCode;
                        } else {fullAddress = apt + " - " + street + ", " + city + ", " + "Ontario " + postalCode;}

                        restaurantAvailable.setName(nameCap);
                        restaurantAvailable.setAddress(fullAddress);
                        restaurantAvailable.setDescription(description);
                        restaurantAvailable.setRating(rating);
                        restaurantAvailable.setTotalRating(totalRating);
                        restaurantAvailable.setTotalReviews(totalReview);

                        listAvailableRestaurants.add(restaurantAvailable);
                    }

                    adapter.notifyDataSetChanged();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void filterList(String s) {
        ArrayList<RestaurantAvailable> filteredList = new ArrayList<>();
        for(RestaurantAvailable restaurantAvailable : listAvailableRestaurants){
            if(restaurantAvailable.getName().toLowerCase(Locale.ROOT).contains(s.toLowerCase(Locale.ROOT)) ||
                    restaurantAvailable.getAddress().toLowerCase(Locale.ROOT).contains(s.toLowerCase(Locale.ROOT))||
                    restaurantAvailable.getDescription().toLowerCase(Locale.ROOT).contains(s.toLowerCase(Locale.ROOT))){
                filteredList.add(restaurantAvailable);
            }
        } if(filteredList.isEmpty()){
            Toast.makeText(getContext(), "No such data found",Toast.LENGTH_SHORT).show();
        } else {
            adapter.setFilteredList(filteredList);
        }

    }

    @Override
    public void onItemClick(int position) {
        RestaurantAvailable restaurantAvailable = listAvailableRestaurants.get(position);
        String nameOfRestaurant = restaurantAvailable.getName().trim();
        Intent intent = new Intent(getContext(),RestaurantMenuClientDashboard.class);
        intent.putExtra("RestaurantName", nameOfRestaurant);
        startActivity(intent);

    }
}