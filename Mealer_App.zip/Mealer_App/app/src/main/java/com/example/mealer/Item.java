package com.example.mealer;

public class Item {
    private String restaurantName, item, category, description,recommendedDish, rating, totalRating, totalReviews;
    private Double price;


    public Item(){

    }
    public Item(String restaurantName, String item, String category, String description, Double price, String recommendedDish, String rating, String totalRating, String totalReviews){
        this.restaurantName = restaurantName;
        this.item = item;
        this.category = category;
        this.description = description;
        this.price = price;
        this.recommendedDish = recommendedDish;
        this.rating = rating;
        this.totalRating = totalRating;
        this.totalReviews = totalReviews;
    }
    public String getRestaurantName(){return restaurantName;}
    public String getItem(){return item;}
    public String getCategory(){return category;}

    public String getDescription(){return description;}
    public Double getPrice(){return price;}
    public String getRecommendedDish(){return recommendedDish;}
    public void setRecommendDish(String x){
        recommendedDish = x;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getTotalRating() {
        return totalRating;
    }

    public void setTotalRating(String totalRating) {
        this.totalRating = totalRating;
    }

    public String getTotalReviews() {
        return totalReviews;
    }

    public void setTotalReviews(String totalReviews) {
        this.totalReviews = totalReviews;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }
}
