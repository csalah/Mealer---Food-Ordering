package com.example.mealer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class OurAdapterMenu extends RecyclerView.Adapter <OurAdapterMenu.MyViewHolder> {
    Context context;
    ArrayList<Item> list;
    private final RecyclerViewInterface recyclerViewInterface;

    public OurAdapterMenu(Context context, ArrayList<Item> list, RecyclerViewInterface recyclerViewInterface) {
        this.context = context;
        this.list = list;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_menu_entry,parent,false);
        return new MyViewHolder(v,recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Item  item  = list.get(position);
        holder.itemName.setText(item.getItem());
        holder.itemDescription.setText(item.getDescription());
        holder.itemPrice.setText(Double.toString(item.getPrice()));

    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemDescription, itemPrice;
        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);
            itemName = itemView.findViewById(R.id.textNameRestaurant);
            itemDescription = itemView.findViewById(R.id.textRestaurantDescription);
            itemPrice = itemView.findViewById(R.id.textRestaurantAddress);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(recyclerViewInterface !=null){
                        int position = getAdapterPosition();
                        if(position!= RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });

        }

    }
}
