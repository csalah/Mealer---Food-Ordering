package com.example.mealer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;

public class

RestaurantDashboard extends AppCompatActivity {
    FirebaseUser user;
    String uid, nameOfRestaurant;
    Dialog onCardViewClick;
    Restaurant resto;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_dashboard);

        user = FirebaseAuth.getInstance().getCurrentUser();
        uid = user.getUid();
        onCardViewClick = new Dialog(this);


        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Users").child(uid);
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Restaurant tempResto = snapshot.getValue(Restaurant.class);
                resto = tempResto;

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        CardView profile;
        profile = findViewById(R.id.cardViewProfile);
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openProfileDialog();
            }
        });

        TextView orders = (TextView) findViewById(R.id.textViewClickHereOrders);
        orders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RestaurantOrderList.class);
                intent.putExtra("RestaurantName", resto.getRestaurantName());
                startActivity(intent);
            }
        });



        CardView recommendedDishes;
        recommendedDishes = findViewById(R.id.cardViewRecommended);
        recommendedDishes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RestaurantDashboard.this,RecommendDish.class));
            }
        });
        CardView menu;
        menu = (CardView)findViewById(R.id.cardViewMenu);
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RestaurantDashboard.this,RestaurantMenu.class));

            }
        });
        CardView logOut;
        logOut = (CardView) findViewById(R.id.cardViewLogout);
       logOut.setOnClickListener(new View.OnClickListener() {
           @Override
            public void onClick(View view) {
               FirebaseAuth.getInstance().signOut();
               finish();
             startActivity(new Intent(RestaurantDashboard.this,UserLoginRegister.class));
           }
        });

        }

    private void openProfileDialog() {

        onCardViewClick.setContentView(R.layout.restaurant_profile_info);
        onCardViewClick.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView nameResto = (TextView) onCardViewClick.findViewById(R.id.textViewName);
        String tempName = resto.getRestaurantName().toLowerCase(Locale.ROOT);
        String nameCap = tempName.substring(0, 1).toUpperCase(Locale.ROOT) + tempName.substring(1);
        nameResto.setText(nameCap);

        TextView address = (TextView) onCardViewClick.findViewById(R.id.textViewAddress);
        String fullAddress;
        if (resto.getAptNumber().equals("") | resto.getAptNumber().equals(null)) {
            fullAddress = (resto.getStreetAddress() + ", " + resto.getCity() + ", " + "Ontario" + " " + resto.getPostalCode().toUpperCase(Locale.ROOT));
        } else{
            fullAddress = (resto.getAptNumber() + " - " + resto.getStreetAddress() + ", " + resto.getCity() + ", " + "Ontario" + " " + resto.getPostalCode().toUpperCase(Locale.ROOT));}
        address.setText(fullAddress);

        TextView email = (TextView) onCardViewClick.findViewById(R.id.textViewEmail);
        email.setText(resto.getEmail());

        TextView desc = (TextView) onCardViewClick.findViewById(R.id.textViewDesc);
        desc.setText("Description: " + resto.getDescription());

        TextView rating = (TextView) onCardViewClick.findViewById(R.id.textViewRating);
        rating.setText("Rating: " + resto.getRating() + " (" + resto.getTotalReviews()+ " reviews)");

        ImageView close = (ImageView) onCardViewClick.findViewById(R.id.imageViewClose);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onCardViewClick.dismiss();
            }
        });  onCardViewClick.show();
    }
}