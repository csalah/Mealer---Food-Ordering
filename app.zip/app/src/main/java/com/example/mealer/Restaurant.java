package com.example.mealer;


public class Restaurant {

    public String restaurantName,firstName, lastName, email, password, StreetAddress, aptNumber, postalCode, city, description,userType,status, UID, rating, totalRatings, totalReviews;

    public Restaurant() {

    }


    public Restaurant(String restaurantName, String firstName, String lastName, String email, String password, String StreetAddress, String aptNumber, String postalCode, String city, String description, String userType, String status, String UID, String rating, String totalRatings, String totalReviews)
    {
        this.restaurantName = restaurantName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.StreetAddress = StreetAddress;
        this.aptNumber = aptNumber;
        this.postalCode = postalCode;
        this.city = city;
        this.description = description;
        this.userType = "Restaurant";
        this.status = "Active";
        this.UID = "";
        this.rating = "N/A";
        this.totalRatings = "0";
        this.totalReviews = "0";
    }

    String getUID(){
        return this.UID;
    }
    String getRestaurantName(){
        return this.restaurantName;
    }
    String getDescription(){return description;}
    String getStatus(){return status;}
    String getAptNumber(){return aptNumber;}
    String getStreetAddress(){return StreetAddress;}
    String getPostalCode(){return postalCode;}
    String getCity(){return city;}



    public String getEmail() {
        return email;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getRating() {
        return rating;
    }

    public String getTotalRatings() {
        return totalRatings;
    }

    public String getTotalReviews() {
        return totalReviews;
    }
}
