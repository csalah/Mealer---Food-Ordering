package com.example.mealer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class OrdersAdapter extends RecyclerView.Adapter <OrdersAdapter.MyViewHolder>{
    Context context;
    ArrayList<Order> list;
    private final RecyclerViewInterface recyclerViewInterface;

    public OrdersAdapter(Context context, ArrayList<Order> list, RecyclerViewInterface recyclerViewInterface) {
        this.context = context;
        this.list = list;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    public void setFilteredList(ArrayList<Order> filteredList){
        this.list = filteredList;
        notifyDataSetChanged();

    }

    @NonNull
    @Override
    public OrdersAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_order_client_entry,parent,false);
        return new OrdersAdapter.MyViewHolder(v,recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull OrdersAdapter.MyViewHolder holder, int position) {
        Order  order  = list.get(position);
        holder.restaurantOrder.setText(order.getRestaurantNameOrder());
        holder.total.setText("Total: $" + order.getTotal());
        holder.status.setText("Status: " + order.getStatus());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView restaurantOrder, total, status;
        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);
            restaurantOrder = itemView.findViewById(R.id.textOrderRestaurant);
            total = itemView.findViewById(R.id.textTotalOrder);
            status = itemView.findViewById(R.id.textStatus);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(recyclerViewInterface !=null){
                        int position = getAdapterPosition();
                        if(position!= RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });

        }

    }
}

