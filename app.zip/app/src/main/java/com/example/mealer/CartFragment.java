package com.example.mealer;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CartFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CartFragment extends Fragment implements RecyclerViewInterface{

    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    CartEntryAdapter adapter;
    ArrayList<CartedItem> listCart;
    String clientEmail, uid;
    FirebaseUser user;
    TextView total;
    Double totalPrice = 0.0;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public CartFragment() {
        // Required empty public constructor
    }


    public static CartFragment newInstance(String param1, String param2) {
        CartFragment fragment = new CartFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cart, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        user = FirebaseAuth.getInstance().getCurrentUser();
        uid = user.getUid();


        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Users");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String email = snapshot.child(uid).child("email").getValue(String.class);
                clientEmail = email;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        databaseReference = FirebaseDatabase.getInstance().getReference("CartedItems");
        recyclerView = view.findViewById(R.id.RecyclerViewCart);
        listCart = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new CartEntryAdapter(getContext(),listCart,this);
        recyclerView.setAdapter(adapter);

        total = (TextView) getView().findViewById(R.id.textViewTotal);
        total.setText("Your total: $0");







        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listCart.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    if (dataSnapshot.child("email").getValue().toString().equals(clientEmail)) {
                        CartedItem cartedItem = dataSnapshot.getValue(CartedItem.class);
                        String name = cartedItem.getRestaurantName();
                        name = name.toLowerCase(Locale.ROOT);
                        String nameCap = name.substring(0,1).toUpperCase(Locale.ROOT) + name.substring(1);
                        cartedItem.setRestaurantName(nameCap);
                        listCart.add(cartedItem);
                    }
                    updateTotal();
                    adapter.notifyDataSetChanged();


                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        Button placeOrder = (Button) getView().findViewById(R.id.submitButton);
        placeOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference db = FirebaseDatabase.getInstance().getReference("CartedItems");
                if(!CartVerified()){
                    Toast.makeText(getActivity(), "Items mismatch. Please make sure you place order for one restaurant at a time", Toast.LENGTH_LONG).show();
                } else {
                    String resto = listCart.get(0).getRestaurantName();
                    Order newOrder = new Order();
                    newOrder.setCustomerEmail(clientEmail);
                    newOrder.setListItems(listCart);
                    newOrder.setRestaurantName(resto);
                    newOrder.setStatus("Pending");
                    newOrder.setTotal("N/A");
                    String email = newOrder.getCustomerEmail();
                    email = email.trim();
                    int index = email.indexOf("@");
                     final String finalEmail = email.substring(0,index);
                    FirebaseDatabase.getInstance().getReference("Orders").child(finalEmail+": "+ resto).setValue(newOrder).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(getActivity(), "Thank you, your order has been placed! Check status of order under the orders tab", Toast.LENGTH_LONG).show();

                            for(CartedItem c : listCart){
                                String id = (finalEmail.trim()+ ": " + c.getRestaurantName().toUpperCase(Locale.ROOT) +": " + c.getItem());
                                System.out.println("ID : " + id);
                                db.child(id).removeValue();
                            }
                            Double databaseTotal = getTotal();
                            listCart.clear();
                            adapter.notifyDataSetChanged();
                            Double tester = updateTotal();
                            total.setText("Your total: $0");
                            DatabaseReference orders = FirebaseDatabase.getInstance().getReference("Orders").child(finalEmail+": "+ resto).child("total");
                            orders.setValue(databaseTotal);
                            //String id = (finalEmail+": "+ resto);
                            //orders.child(id).child("total").setValue(String.valueOf(databaseTotal));

                        }
                    });



                }
            }
        });


    }

    private boolean CartVerified() {
        boolean goodToOrder = true;
        CartedItem firstItem = listCart.get(0);
        String firstItemRestaurant = firstItem.getRestaurantName();
        for(CartedItem c : listCart){
            if(!c.getRestaurantName().equals(firstItemRestaurant)){ goodToOrder = false;}
        }
        return goodToOrder;
    }

    private Double updateTotal() {
        double temp = 0.0;
        System.out.println("Current temp " + temp);
        total.setText("");
        if(listCart.isEmpty()){total.setText("Your total: $0");
        }else
            System.out.println("Size : " + listCart.size());
        for(CartedItem c : listCart){
            double currentItemPrice = Double.valueOf(c.getPrice());
            int quantity = Integer.parseInt(c.getQuantity());
            System.out.println(currentItemPrice + ", " + quantity);
            double totalItem = currentItemPrice * quantity;
            temp = temp + totalItem;
            System.out.println("after item" + temp);
        }
        this.totalPrice = temp;
        total.setText("");
        total.setText("Your total: " + "$" + this.totalPrice);
        return this.totalPrice;
    }

    public Double getTotal(){
        return totalPrice;
    }


    @Override
    public void onItemClick(int position) {

    }
}