
package com.example.mealer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
public class CartEntryAdapter extends RecyclerView.Adapter <CartEntryAdapter.MyViewHolder>{
    Context context;
    ArrayList<CartedItem> list;
    private final RecyclerViewInterface recyclerViewInterface;

    public CartEntryAdapter(Context context, ArrayList<CartedItem> list, RecyclerViewInterface recyclerViewInterface) {
        this.context = context;
        this.list = list;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    @NonNull
    @Override
    public CartEntryAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.client_cart_entry_layout,parent,false);
        return new CartEntryAdapter.MyViewHolder(v,recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull CartEntryAdapter.MyViewHolder holder, int position) {
        CartedItem  cartedItem  = list.get(position);
        holder.nameItem.setText(cartedItem.getItem());
        holder.descriptionItem.setText(cartedItem.getDescription());
        holder.nameRestaurant.setText("Restaurant: " + cartedItem.getRestaurantName());
        holder.price.setText("Price: " + cartedItem.getPrice());
        holder.quantity.setText("Quantity: " + cartedItem.getQuantity());
        holder.rating.setText("Rating: ");



    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView nameItem, descriptionItem, nameRestaurant, quantity, price, rating;
        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);
            nameItem = itemView.findViewById(R.id.textNameItem);
            descriptionItem = itemView.findViewById(R.id.textItemDescription);
            nameRestaurant = itemView.findViewById(R.id.textItemNameRestaurant);
            price = itemView.findViewById(R.id.textItemPrice);
            quantity = itemView.findViewById(R.id.textItemQuantity);
            rating = itemView.findViewById(R.id.textRating);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(recyclerViewInterface !=null){
                        int position = getAdapterPosition();
                        if(position!= RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });

        }

    }
}

