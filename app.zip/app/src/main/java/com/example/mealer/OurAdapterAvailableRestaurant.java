package com.example.mealer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class OurAdapterAvailableRestaurant extends RecyclerView.Adapter <OurAdapterAvailableRestaurant.MyViewHolder>{
    Context context;
    ArrayList<RestaurantAvailable> list;
    private final RecyclerViewInterface recyclerViewInterface;

    public OurAdapterAvailableRestaurant(Context context, ArrayList<RestaurantAvailable> list, RecyclerViewInterface recyclerViewInterface) {
        this.context = context;
        this.list = list;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    public void setFilteredList(ArrayList<RestaurantAvailable> filteredList){
        this.list = filteredList;
        notifyDataSetChanged();

    }

    @NonNull
    @Override
    public OurAdapterAvailableRestaurant.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_available_restaurant_entry,parent,false);
        return new OurAdapterAvailableRestaurant.MyViewHolder(v,recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull OurAdapterAvailableRestaurant.MyViewHolder holder, int position) {
        RestaurantAvailable  restaurantAvailable  = list.get(position);
        holder.restaurantName.setText(restaurantAvailable.getName());
        holder.restaurantDescription.setText(restaurantAvailable.getDescription());
        holder.restaurantAddress.setText(restaurantAvailable.getAddress());
        holder.rating.setText("Rating: "+ restaurantAvailable.getRating() + " (" + restaurantAvailable.getTotalReviews()+ " reviews)");

    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView restaurantName, restaurantDescription, restaurantAddress, rating;
        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);
            restaurantName = itemView.findViewById(R.id.textNameRestaurant);
            restaurantDescription = itemView.findViewById(R.id.textRestaurantDescription);
            restaurantAddress = itemView.findViewById(R.id.textRestaurantAddress);
            rating = itemView.findViewById(R.id.textRating);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(recyclerViewInterface !=null){
                        int position = getAdapterPosition();
                        if(position!= RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });

        }

    }
}
