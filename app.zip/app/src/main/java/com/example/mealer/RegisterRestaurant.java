package com.example.mealer;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Locale;

public class RegisterRestaurant extends AppCompatActivity implements View.OnClickListener{
    private FirebaseAuth mnAuth;
    Uri uri;
    private final int GALLERY_REQUESTING_CODE= 1000;
    FloatingActionButton goBack;
    Button createAccount;
    ImageView voidCheque;
    EditText editTextRestaurantName, editTextFirstName, editTextLastName, editTextEmail, editTextPassword, editTextConfirmPassword, editTextStreetAddress,editTextApt, editTextPostalCode, editTextCity, editTextDescription;
    CheckBox showPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_restaurant);

        mnAuth = FirebaseAuth.getInstance();
        TextView clickHereVoidCheque;


        editTextFirstName = (EditText) findViewById(R.id.firstNameField);
        editTextLastName = (EditText) findViewById(R.id.lastNameField);
        editTextEmail = (EditText) findViewById(R.id.userEmailField);
        editTextPassword = (EditText) findViewById(R.id.userPasswordField);
        editTextConfirmPassword = (EditText) findViewById(R.id.confirmPassword);
        editTextStreetAddress = (EditText) findViewById(R.id.pickUpStreetAddress);
        editTextApt = (EditText) findViewById(R.id.pickUpAptNumber);
        editTextCity = (EditText) findViewById(R.id.pickUpCity);
        editTextPostalCode = (EditText) findViewById(R.id.pickUpPostalCode);
        editTextDescription = (EditText) findViewById(R.id.restaurantDescription);
        editTextRestaurantName = (EditText) findViewById(R.id.restaurantName);
        createAccount = (Button)findViewById(R.id.btnCreateAccount);
        createAccount.setOnClickListener(this);

        goBack = (FloatingActionButton) findViewById(R.id.btnGoBack);
        goBack.setOnClickListener(this);
        showPass = findViewById(R.id.checkBoxPasswords);
        showPass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){editTextPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    editTextConfirmPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else{editTextPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    editTextConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }
            }
        });

        voidCheque = (ImageView) findViewById(R.id.restaurantVoidCheque);
        clickHereVoidCheque = (TextView) findViewById(R.id.uploadVoidChequeTextView);
        clickHereVoidCheque.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,"Title"), GALLERY_REQUESTING_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==GALLERY_REQUESTING_CODE)
        {
            uri = data.getData();
            voidCheque.setImageURI(uri);
        }


        }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnGoBack:
                finish();
                break;
            case R.id.btnCreateAccount:
                createAccount();
                break;

        }
    }

    private void createAccount() {
        String restaurantName = editTextRestaurantName.getText().toString().toUpperCase(Locale.ROOT).trim().replaceAll("\\s","");
        String firstName = editTextFirstName.getText().toString().trim();
        String lastName = editTextLastName.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String confirmPassword = editTextConfirmPassword.getText().toString().trim();
        String streetAddress = editTextStreetAddress.getText().toString().trim();
        String aptNumber = editTextApt.getText().toString().trim();
        String postalCode = editTextPostalCode.getText().toString().trim();
        String city = editTextCity.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();
        String userType = "Restaurant";
        String status = "Active";
        String UID = "";
        ImageView voidCheque = findViewById(R.id.restaurantVoidCheque);

        if(firstName.isEmpty()){
            editTextFirstName.setError("First name is required!");
            editTextFirstName.requestFocus();
            return;
        }
        if(lastName.isEmpty()){
            editTextLastName.setError("Last name is required!");
            editTextLastName.requestFocus();
            return;
        }
        if(email.isEmpty()){
            editTextEmail.setError("Email is required!");
            editTextEmail.requestFocus();
            return;
        }
        //This code will verify if email matches common domains such as gmail,hotmail..etc.
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            editTextEmail.setError("Please enter a valid email address!");
            editTextEmail.requestFocus();
            return;
        }
        if(password.isEmpty()){
            editTextPassword.setError("A valid password is required!");
            editTextPassword.requestFocus();
            return;
        }
        if(password.length() < 6){
            editTextPassword.setError("Password is too short, a minimum of 6 characters is required!");
            editTextPassword.requestFocus();
            return;
        }
        if(confirmPassword.isEmpty()){
            editTextConfirmPassword.setError("Please confirm password!");
            editTextConfirmPassword.requestFocus();
            return;
        }
        if(!password.equals(confirmPassword)) {
            editTextPassword.setError("Passwords do not match!");
            editTextPassword.requestFocus();
            return;
        }
        if(streetAddress.isEmpty()){
            editTextStreetAddress.setError("A valid address is required!");
            editTextStreetAddress.requestFocus();
            return;
        }
        if (city.isEmpty()) {
            editTextCity.setError("A valid city is required!");
            editTextCity.requestFocus();
            return;
        }
        if(postalCode.isEmpty() || postalCode.length() != 6){
            editTextPostalCode.setError("A valid postal code is required!");
            editTextPostalCode.requestFocus();
            return;
        }
        if (description.isEmpty()) {
            editTextDescription.setError("A description of yourself is required!");
            editTextDescription.requestFocus();
            return;
        }

        mnAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {

            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    Restaurant restaurant = new Restaurant(restaurantName,firstName , lastName , email , password  , streetAddress , aptNumber , postalCode , city ,description, userType, status, UID,"N/A", "0","0");
                    FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(restaurant).
                            addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        DatabaseReference db;
                                        String currentUID;
                                        currentUID = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                        db = FirebaseDatabase.getInstance().getReference("Users");
                                        db.child(currentUID).child("UID").setValue(currentUID);

                                        Toast.makeText(RegisterRestaurant.this, "Welcome to Mealer, you've been successfully registered as a restaurant!", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(getApplicationContext(),UserLoginRegister.class));
                                    } else {
                                        Toast.makeText(RegisterRestaurant .this,"Unable to register",Toast.LENGTH_LONG).show();
                                    }
                                }
                            });


                } else {
                    Toast.makeText(RegisterRestaurant.this,"Unable to register" , Toast.LENGTH_LONG).show();
                }

            }
        });
    }
}