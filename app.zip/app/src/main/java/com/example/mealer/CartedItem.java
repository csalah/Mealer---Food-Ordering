package com.example.mealer;

public class CartedItem {
    private String restaurantName, item, description, price, quantity,email;

    public CartedItem(){

    }

    public CartedItem(String restaurantName,String item, String description, String price, String quantity, String email){
        this.restaurantName = restaurantName;
        this.item = item;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.email = email;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
}
