package com.example.mealer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class RecommendDish extends AppCompatActivity implements RecyclerViewInterface{
    ImageView returnImg;
    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    OurAdapterMenu adapter;
    ArrayList<Item> listItems;
    FirebaseUser user;
    String uid;
    String restaurantName;
    Dialog onItemClick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommend_dish);
        user = FirebaseAuth.getInstance().getCurrentUser();
        uid = user.getUid();
        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Users");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String name = snapshot.child(uid).child("restaurantName").getValue().toString();
                restaurantName = name;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        databaseReference = FirebaseDatabase.getInstance().getReference("Items");
        onItemClick = new Dialog(this);
        recyclerView = findViewById(R.id.recyclerView);
        listItems = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new OurAdapterMenu(this, listItems,this);
        recyclerView.setAdapter(adapter);

        returnImg = (ImageView) findViewById(R.id.imageViewReturn);
        returnImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                startActivity(new Intent(getApplicationContext(), RestaurantDashboard.class));
            }
        });
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listItems.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    if (dataSnapshot.child("restaurantName").getValue().toString().equals(restaurantName) && dataSnapshot.child("recommendedDish").getValue().toString().equals("Y")) {
                        Item item = dataSnapshot.getValue(Item.class);
                        listItems.add(item);
                    }

                    adapter.notifyDataSetChanged();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }//end of onCreate

    @Override
    public void onItemClick(int position) {
        Item itemListed = listItems.get(position);
        String restaurantItem = itemListed.getRestaurantName().toString().trim();
        String nameItem = itemListed.getItem();
        openItemDialog(restaurantItem,nameItem);

    }

    private void openItemDialog(String restaurantItem, String nameItem) {
        onItemClick.setContentView(R.layout.item_recommended_menu_dialog);
        onItemClick.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        onItemClick.show();
        DatabaseReference db;
        db = FirebaseDatabase.getInstance().getReference("Items").child(restaurantItem+": "+ nameItem);
        Button btnYes = onItemClick.findViewById(R.id.btnYes);
        btnYes.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                db.child("recommendedDish").setValue("N").addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            adapter.notifyDataSetChanged();
                            Toast.makeText(RecommendDish.this, "This item was successfully removed from your recommended dishes ", Toast.LENGTH_LONG).show();
                            onItemClick.dismiss();

                        } else{Toast.makeText(RecommendDish.this, "Unable to remove item from your recommended dishes ", Toast.LENGTH_LONG).show();}
                    }
                });
            }
        });
        Button btnNo = onItemClick.findViewById(R.id.btnNo);
        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClick.dismiss();
            }
        });
        ImageView close = onItemClick.findViewById(R.id.imageViewClose);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClick.dismiss();
            }
        });
    }
}