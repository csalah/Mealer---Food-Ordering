package com.example.mealer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class RestaurantMenu extends AppCompatActivity implements RecyclerViewInterface {
    ImageView returnImg, addItem;
    Dialog addItemDialog;
    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    OurAdapterMenu adapter;
    ArrayList<Item> listItems;
    EditText nameOfItem, descriptionOfItem,priceOfItem, categoryOfItem;
    DatabaseReference reference;
    FirebaseDatabase rootNode;
    FirebaseUser user;
    String uid;
    String restaurantName;
    Dialog onItemClick;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_menu);
        user = FirebaseAuth.getInstance().getCurrentUser();
        uid = user.getUid();
        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Users");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String name = snapshot.child(uid).child("restaurantName").getValue().toString();
                restaurantName = name;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        databaseReference = FirebaseDatabase.getInstance().getReference("Items");
        addItemDialog = new Dialog(this);
        onItemClick = new Dialog(this);
        recyclerView = findViewById(R.id.recyclerView);
        listItems = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new OurAdapterMenu(this, listItems,this);
        recyclerView.setAdapter(adapter);


        addItem = (ImageView)findViewById(R.id.imageAdd);
        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });
        returnImg = (ImageView) findViewById(R.id.imageViewReturn);
        returnImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                startActivity(new Intent(getApplicationContext(), RestaurantDashboard.class));
            }
        });

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listItems.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    if (dataSnapshot.child("restaurantName").getValue().toString().equals(restaurantName)) {
                        Item item = dataSnapshot.getValue(Item.class);
                        listItems.add(item);
                    }

                    adapter.notifyDataSetChanged();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void openDialog(){
        addItemDialog.setContentView(R.layout.restaurant_add_item_dialog);
        addItemDialog.show();
        addItemDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Button addItem = addItemDialog.findViewById(R.id.btnAddItem);
        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                nameOfItem = addItemDialog.findViewById(R.id.editTextNameItem);
                descriptionOfItem = addItemDialog.findViewById(R.id.editTextDescriptionItem);
                priceOfItem = addItemDialog.findViewById(R.id.editTextPriceItem);
                categoryOfItem = addItemDialog.findViewById(R.id.editTextCategory);
                String nameItem = nameOfItem.getText().toString().trim();
                String descriptionItem = descriptionOfItem.getText().toString().trim();
                String priceItem = priceOfItem.getText().toString().trim();
                String categoryItem = categoryOfItem.getText().toString().trim();


                if(nameItem.isEmpty()){
                    nameOfItem.setError("Name of item is required");
                    nameOfItem.requestFocus();
                    return;
                }
                if(categoryItem.isEmpty()){
                    categoryOfItem.setError("Category of item is required");
                    categoryOfItem.requestFocus();
                    return;
                }
                if(descriptionItem.isEmpty()){
                    descriptionOfItem.setError("Description of item is required");
                    descriptionOfItem.requestFocus();
                    return;

                }

                if(priceItem.isEmpty()){
                    priceOfItem.setError("Price of item is required");
                    priceOfItem.requestFocus();
                    return;

                }

                rootNode = FirebaseDatabase.getInstance();
                reference  = rootNode.getReference("Items");
                Item item = new Item(restaurantName, nameItem, categoryItem, descriptionItem,Double.parseDouble(priceItem),"N", "N/A", "0", "0");
                FirebaseDatabase.getInstance().getReference("Items").child(restaurantName+": "+ nameItem).setValue(item).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            adapter.notifyDataSetChanged();
                            Toast.makeText(RestaurantMenu.this, "New item was successfully added to your menu!", Toast.LENGTH_LONG).show();
                            addItemDialog.dismiss();

                        } else {Toast.makeText(RestaurantMenu.this, "Unable to add new item to menu", Toast.LENGTH_LONG).show();
                        }

                    }
                });


            }
        });

        ImageView close = addItemDialog.findViewById(R.id.imageViewClose);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addItemDialog.dismiss();
            }
        });
    }

    @Override
    public void onItemClick(int position) {
        Item itemListed = listItems.get(position);
        String restaurantItem = itemListed.getRestaurantName().toString().trim();
        String nameItem = itemListed.getItem();
        String recommendedDish = itemListed.getRecommendedDish();
        openItemDialog(restaurantItem,nameItem,recommendedDish);
    }

    private void openItemDialog(String restaurantItem, String nameItem, String recommendedDish) {
        onItemClick.setContentView(R.layout.menu_item_remove_addsuggested_dialog);
        onItemClick.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        onItemClick.show();
        DatabaseReference db;
        db = FirebaseDatabase.getInstance().getReference("Items").child(restaurantItem+": "+ nameItem);
        Button addToRecommended = onItemClick.findViewById(R.id.btnAddSuggested);
        addToRecommended.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(recommendedDish.equals("Y")){
                    Toast.makeText(RestaurantMenu.this, "This item is already in your recommended dishes", Toast.LENGTH_LONG).show();
                } else {
                    db.child("recommendedDish").setValue("Y").addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                adapter.notifyDataSetChanged();
                                Toast.makeText(RestaurantMenu.this, "This item was successfully added your recommended dishes ", Toast.LENGTH_LONG).show();
                                onItemClick.dismiss();

                            } else{ Toast.makeText(RestaurantMenu.this, "Unable to add item to recommended dishes", Toast.LENGTH_LONG).show();}
                        }
                    });
                }

            }
        });
        Button btnRemoveItem = onItemClick.findViewById(R.id.btnRemoveItem);
        btnRemoveItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (recommendedDish.equals("Y")) {
                    Toast.makeText(RestaurantMenu.this, "Please remove item from recommended dishes first!", Toast.LENGTH_LONG).show();
                } else {
                    db.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                adapter.notifyDataSetChanged();
                                Toast.makeText(RestaurantMenu.this, "Item: " + nameItem + " was successfully removed from your menu!", Toast.LENGTH_LONG).show();
                                onItemClick.dismiss();
                            } else {
                                Toast.makeText(RestaurantMenu.this, "Unable to add item your menu", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
            }
            }
        });
        ImageView close = onItemClick.findViewById(R.id.imageViewClose);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClick.dismiss();
            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
        startActivity(new Intent(getApplicationContext(),RestaurantDashboard.class));

        //super.onBackPressed();
    }

    public int getItemListSize(List<Item> list){
        return list.size();
    }


}