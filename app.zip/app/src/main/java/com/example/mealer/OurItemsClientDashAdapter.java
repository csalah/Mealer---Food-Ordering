package com.example.mealer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class OurItemsClientDashAdapter extends RecyclerView.Adapter <OurItemsClientDashAdapter.MyViewHolder>{
    Context context;
    ArrayList<Item> list;
    private final RecyclerViewInterface recyclerViewInterface;

    public OurItemsClientDashAdapter(Context context, ArrayList<Item> list, RecyclerViewInterface recyclerViewInterface) {
        this.context = context;
        this.list = list;
        this.recyclerViewInterface = recyclerViewInterface;
    }
    public void setFilteredList(ArrayList<Item> filteredList){
        this.list = filteredList;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public OurItemsClientDashAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_items_client_dashboard_entry,parent,false);
        return new OurItemsClientDashAdapter.MyViewHolder(v,recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull OurItemsClientDashAdapter.MyViewHolder holder, int position) {
        Item  item  = list.get(position);
        holder.name.setText(item.getItem());
        holder.description.setText(item.getDescription());
        holder.price.setText("$" + item.getPrice().toString());
        if(item.getRecommendedDish().equals("N")){
            holder.recommended.setText("");
        }
        holder.rating.setText("Item rating: " + item.getRating() + " (" + item.getTotalReviews() + " reviews)");
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name, description, price, recommended, rating;
        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);
             name = itemView.findViewById(R.id.textNameItem);
            description = itemView.findViewById(R.id.textItemDescription);
            price = itemView.findViewById(R.id.textItemPrice);
            recommended = itemView.findViewById(R.id.textRecommended);
            rating  = itemView.findViewById(R.id.textItemRatingDish);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(recyclerViewInterface !=null){
                        int position = getAdapterPosition();
                        if(position!= RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });

        }

    }
}
