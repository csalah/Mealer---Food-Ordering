package com.example.mealer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.*;

public class AdminDashboard extends AppCompatActivity implements RecyclerViewInterface{
    RecyclerView recyclerView;
    ArrayList<Complaint> list;
    DatabaseReference databaseReference;
    DatabaseReference databaseReferenceRestos;
    OurAdapter adapter;
    Dialog dialog;
    ArrayList<Restaurant> listRestaurants;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);
        dialog = new Dialog(this);
        recyclerView = findViewById(R.id.recyclerView);
        databaseReference = FirebaseDatabase.getInstance().getReference("Complaints");
        list = new ArrayList<>();
        listRestaurants = new ArrayList<>();
        databaseReferenceRestos = FirebaseDatabase.getInstance().getReference("Users");
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new OurAdapter(this, list,this);
        recyclerView.setAdapter(adapter);
        databaseReferenceRestos.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot: snapshot.getChildren()) {
                    if(dataSnapshot.child("UID").exists()){
                    Restaurant resto = dataSnapshot.getValue(Restaurant.class);
                    listRestaurants.add(resto);
                    } else continue;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot: snapshot.getChildren()) {
                Complaint complaint = dataSnapshot.getValue(Complaint.class);
                list.add(complaint);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        Button logOut = (Button) findViewById(R.id.btnLogOut2);
        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(AdminDashboard.this,UserLoginRegister.class));
            }
        });//end of onClick for logoutBtn
    }// end of Oncreate

    @Override
    public void onItemClick(int position) {
        Complaint complaintListed = list.get(position);
        String nameOfRestaurant = complaintListed.getRestaurantName().toString().trim();
        String complaintFromClient = complaintListed.getComplaintDetails().toString().trim();
        openDialog(nameOfRestaurant, complaintFromClient,position);
    }

    private void openDialog(String nameOfRestaurant, String complaintFromClient, int pos) {
        String name = nameOfRestaurant;
        String complaint = complaintFromClient;
        int position = pos;
        dialog.setContentView(R.layout.admin_action_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        Button btnSuspend = dialog.findViewById(R.id.btnSuspend);
        btnSuspend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uidOfResto = null;
                for(Restaurant r: listRestaurants){
                    if(r.getRestaurantName().equals(nameOfRestaurant)){uidOfResto = r.getUID() ;}
                } if(uidOfResto==null){ dialog.dismiss();
                    Toast.makeText(AdminDashboard.this, "Cannot locate restaurant in database! Please dismiss" , Toast.LENGTH_LONG).show();
                    return;
                }
                DatabaseReference db;
                db = FirebaseDatabase.getInstance().getReference("Users");
                db.child(uidOfResto).child("status").setValue("Suspended").addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            DatabaseReference dbComp;
                            dbComp = FirebaseDatabase.getInstance().getReference("Complaints");
                            dbComp.child("Complaint for: " +nameOfRestaurant).removeValue();
                            list.remove(pos);
                            adapter.notifyDataSetChanged();
                            Toast.makeText(AdminDashboard.this, "User was suspended for 10 days." , Toast.LENGTH_LONG).show();
                            dialog.dismiss();
                        } else { Toast.makeText(AdminDashboard.this, "Unable to delete user!" , Toast.LENGTH_LONG).show();
                        }
                    }

                });
            }
        });
        Button delete = dialog.findViewById(R.id.btnDelete);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uidOfResto = null;
                for(Restaurant r: listRestaurants){
                    if(r.getRestaurantName().equals(nameOfRestaurant)){uidOfResto = r.getUID() ;}
                } if(uidOfResto==null){
                    Toast.makeText(AdminDashboard.this, "Cannot locate restaurant in database!" , Toast.LENGTH_LONG).show();
                    return;
                }
                DatabaseReference db;
                db = FirebaseDatabase.getInstance().getReference("Users");
                db.child(uidOfResto).child("status").setValue("Deleted").addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            DatabaseReference dbComp;
                            dbComp = FirebaseDatabase.getInstance().getReference("Complaints");
                            dbComp.child("Complaint for: " +nameOfRestaurant).removeValue();
                            list.remove(pos);
                            adapter.notifyDataSetChanged();
                            Toast.makeText(AdminDashboard.this, "User was permanently deleted." , Toast.LENGTH_LONG).show();
                            dialog.dismiss();
                        } else { Toast.makeText(AdminDashboard.this, "Unable to delete user!" , Toast.LENGTH_LONG).show();
                        }
                    }

                });

            }
        });
        Button dismiss = dialog.findViewById(R.id.btnDismiss);
        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference db;
                db = FirebaseDatabase.getInstance().getReference("Complaints");
                db.child("Complaint for: " +nameOfRestaurant).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                        list.remove(pos);
                        adapter.notifyDataSetChanged();
                        Toast.makeText(AdminDashboard.this, "Complaint was successfully dismissed." , Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                    } else { Toast.makeText(AdminDashboard.this, "Unable to dismiss complaint!" , Toast.LENGTH_LONG).show();
                        }
                    }

                });


            }
        });
        ImageView close = dialog.findViewById(R.id.imageViewClose);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }


}// end of AdminDashboard class