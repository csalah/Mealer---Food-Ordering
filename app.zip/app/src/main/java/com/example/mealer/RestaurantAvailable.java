package com.example.mealer;

public class RestaurantAvailable {
    private String name, address, status, description, rating, totalRating, totalReviews;

    public RestaurantAvailable(){}

    public RestaurantAvailable(String name, String address, String status, String description, String rating, String totalRating, String totalReviews){
        this.name = name;
        this.address = address;
        this. status = status;
        this.description = description;
        this.rating = rating;
        this.totalRating = totalRating;
        this.totalReviews = totalReviews;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getTotalRating() {
        return totalRating;
    }

    public void setTotalRating(String totalRating) {
        this.totalRating = totalRating;
    }

    public String getTotalReviews() {
        return totalReviews;
    }

    public void setTotalReviews(String totalReviews) {
        this.totalReviews = totalReviews;
    }
}
