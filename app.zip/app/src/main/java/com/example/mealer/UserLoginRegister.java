package com.example.mealer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class UserLoginRegister extends AppCompatActivity implements View.OnClickListener {
    private EditText emailField,passwordField;
    private FirebaseAuth mAuth;
    private FirebaseUser user;
    private DatabaseReference reference;
    private DatabaseReference status;
    private ProgressBar progressBar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login_register);
        TextView registerUser;
        CheckBox showPass;
        Button btnLogin;
        registerUser = (TextView) findViewById(R.id.registerUser);
        registerUser.setOnClickListener(this);
        mAuth = FirebaseAuth.getInstance();
        emailField = (EditText)findViewById(R.id.emailField);
        passwordField = (EditText) findViewById(R.id.passwordField);
        showPass = findViewById(R.id.checkBoxPassword);
        showPass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){passwordField.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else {passwordField.setTransformationMethod(PasswordTransformationMethod.getInstance());}
            }
        });
        btnLogin = (Button)findViewById(R.id.btnLogIn);
        btnLogin.setOnClickListener(this);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.registerUser:
                progressBar.setVisibility(View.VISIBLE);
                finish();
                startActivity(new Intent(this,UserType.class));
                break;
            case R.id.btnLogIn:
                userLogin();
                break;
        }
    }

    private void userLogin() {
        String email, password;
        email = emailField.getText().toString().trim();
        password = passwordField.getText().toString().trim();

        if(email.isEmpty()){
            emailField.setError("Please enter your email");
            emailField.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            emailField.setError("Invalid Email");
            emailField.requestFocus();
            return;
        }
        if(password.isEmpty() || password.length() < 6){
            passwordField.setError("Please verify your password");
            passwordField.requestFocus();
            return;
        }
        if(email.equals("infomealer@gmail.com") && password.equals("Admin123")){
            progressBar.setVisibility(View.VISIBLE);
            finish();
            startActivity(new Intent(getApplicationContext(),AdminDashboard.class));
        } progressBar.setVisibility(View.VISIBLE);
            mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {

                        dashboardSelection();

                    } else {
                        Toast.makeText(UserLoginRegister.this, "Unable to login, please verify your login information", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                        passwordField.setText("");
                        passwordField.requestFocus();

                    }
                }

                private void dashboardSelection() {
                    user = FirebaseAuth.getInstance().getCurrentUser();
                    String iD = user.getUid();

                    reference = FirebaseDatabase.getInstance().getReference("Users").child(iD).child("userType");
                    status = FirebaseDatabase.getInstance().getReference("Users").child(iD).child("status");

                    reference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            snapshot.getChildren();
                            String userType = snapshot.getValue().toString();

                             if (userType.equals("Client")) {
                                 finish();
                                startActivity(new Intent(getApplicationContext(), ClientDashboard.class));

                            }

                            else if (userType.equals("Restaurant")) {
                                 status.addValueEventListener(new ValueEventListener()
                                 {
                                     @Override
                                     public void onDataChange(@NonNull DataSnapshot snapshot) {
                                         snapshot.getChildren();
                                         String statusRestaurant = snapshot.getValue().toString();
                                         switch (statusRestaurant) {
                                             case "Suspended":
                                                 progressBar.setVisibility(View.GONE);
                                                 Toast.makeText(UserLoginRegister.this, "You've been temporarily suspended for 10 days.", Toast.LENGTH_LONG).show();
                                                 break;
                                             case "Deleted":
                                                 progressBar.setVisibility(View.GONE);
                                                 Toast.makeText(UserLoginRegister.this, "Your access was permanently deleted.", Toast.LENGTH_LONG).show();
                                                 break;
                                             default:
                                                 finish();
                                                 startActivity(new Intent(getApplicationContext(), RestaurantDashboard.class));
                                                 break;
                                         }

                                     }

                                     @Override
                                     public void onCancelled(@NonNull DatabaseError error) {

                                     }
                                 });
                                 //startActivity(new Intent(getApplicationContext(), RestaurantDashboard.class));
                            }
                            else if (userType.equals("Admin")){
                                finish();
                                startActivity(new Intent(getApplicationContext(), AdminDashboard.class));
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }


                    });



                }// end of dashSelect
            });

    }
}